﻿using FrontToBack.DAL;
using FrontToBack.Models;
using FrontToBack.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBack.Controllers
{
    public class BasketController : Controller
    {
        private readonly Context _context;
        public BasketController(Context context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> AddBasket(int? id)
        {
            if (id == null) return RedirectToAction("Index","Error");
            Product product =await  _context.Products.FindAsync(id);
            if(product==null) return RedirectToAction("Index","Error");
            List<Basket> baskets; ;
            //if (Request.Cookies["basket"] != null)
            //{

            //}
            string basket = Request.Cookies["basket"];
            List<Basket> basketCookie = JsonConvert.DeserializeObject<List<Basket>>(basket);
            Basket isExist = basketCookie.FirstOrDefault(b => b.Id == product.Id);
            Basket basketVm = new Basket();
           
            if (isExist == null)
            {
                basketVm.Id = product.Id;
                basketVm.ImageUrl = product.ImageUrl;
                basketVm.Price = product.Price;
                basketVm.Count = 1;

                basketCookie.Add(basketVm);

            }
            else
            {
                isExist.Count++;
            }

           
            string basketsCookies= JsonConvert.SerializeObject(basketCookie);

            Response.Cookies.Append("basket", basketsCookies, new CookieOptions() { MaxAge = TimeSpan.FromMinutes(20)});

            return Content("added");
        }
        public IActionResult Basket()
        {
            string basket=Request.Cookies["basket"];
            List<Basket> product = JsonConvert.DeserializeObject<List<Basket>>(basket);
            return Content("okay");
        }
    }
}
